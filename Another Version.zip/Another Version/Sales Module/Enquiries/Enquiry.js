
$(document).ready(function(){
	$('.menu-toggle').click(function(){
		$('nav').toggleClass('Nactive');
	})
	$('.sub-menu').click(function(){
		$(this).siblings().removeClass('dactive');
		$(this).toggleClass('dactive');
	})
	$('[data-toggle="popover"]').popover();
})


$("#searchToggle").on("click", function(){
  $(".advancedSearch").slideToggle();             // .fadeToggle() // .slideToggle()
});


$('#enqDateFrom').datepicker({
					 uiLibrary: 'bootstrap4'
			 });
$('#enqDateTo').datepicker({
			 					 uiLibrary: 'bootstrap4'
			 			 });

$('.btnHam').click(function(){
		 $(this).toggleClass("click");
		 $('.sidebar').toggleClass("show");
	 });


		 $('.enq-btn').click(function(){
			 $('.sidebar ul .enq-show').toggleClass("showE");
			 $('.sidebar ul .enq').toggleClass("rotate");
		 });

		 $('.quot-btn').click(function(){
		        $('.sidebar ul .quot-show').toggleClass("showQ");
		        $('.sidebar ul .quot').toggleClass("rotate");
		      });
		 $('.ord-btn').click(function(){
		 		        $('.sidebar ul .ord-show').toggleClass("showO");
		 		        $('.sidebar ul .ord').toggleClass("rotate");
		 		      });

		$('.sidebar ul li').click(function(){
			         $(this).addClass("active").siblings().removeClass("active");
			     });


		 $('.SearchExpand').click(function(){
						 $('.rotate-icon').toggleClass("rotate");
					 });


          var hamburger = document.querySelector(".btnHam");

					 hamburger.addEventListener("click", () => {
					 	hamburger.closest(".wrapper").classList.toggle("click_collapse");
					 	hamburger.closest(".wrapper").classList.toggle("hover_collapse");
					 })


 //Table Responsive function
 $(window).on('resize', function(){
      var win = $(this);
      if (win.width() < 991) {
      $('#enqTable').addClass('table-responsive');
      }
    else
    {
        $('#enqTable').removeClass('table-responsive');
    }

});
