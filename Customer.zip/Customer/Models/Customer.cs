﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Customer.Models
{
    public class Customer
    {

        public int value;
        public string Name;

        public string CustomerCode;
        public string CustomerName;
        public string Category;

        public string CustomerSale;

        public  List<Details> lstDetails;
        public List<Account> lstAccounts;
    }

    public class Details
    {
        public int Emp { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public string Telephone { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
    }

    public class Account
    {
        public DateTime Date { get; set; }
        public string RefNo { get; set; }
        public string Remarks { get; set; }
        public string Value { get; set; }

    }
}