﻿using Customer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Customer.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            
                Customer.Models.Customer objCustomers = new Customer.Models.Customer();
                objCustomers.lstDetails = new List<Details>();
                objCustomers.lstDetails.Add(new Models.Details { Emp = 1, Name = "Test1", Designation = "", Email = "", Mobile = "", Telephone = "" });
                objCustomers.value = 1;
                objCustomers.Name = "Customer";
                return View(objCustomers);
            
        }

        public ActionResult Index1()
        {


            
                Customer.Models.Customer objCustomers = new Customer.Models.Customer();
                objCustomers.lstAccounts = new List<Account>();
                objCustomers.lstAccounts.Add(new Models.Account { Date = DateTime.Now, RefNo = "12345", Remarks = "", Value = "" });
                objCustomers.Name = "Account";
                return View("Index",objCustomers);
            
        }



        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            List<Member> members = new List<Member>();
            members = GetMemberList();
            return View(members);
        }
        private List<Member> GetMemberList()
        {
            List<Member> members = new List<Member>();
            members.Add(new Member { Name = "member1" });
            members.Add(new Member { Name = "member2" });
            members.Add(new Member { Name = "member3" });
            members.Add(new Member { Name = "member4" });
            members.Add(new Member { Name = "member5" });
            return members;
        }


        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}